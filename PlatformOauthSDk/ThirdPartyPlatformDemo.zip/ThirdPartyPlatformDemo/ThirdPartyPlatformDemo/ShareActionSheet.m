//
//  ShareActionSheet.m
//  ThirdPartyPlatformDemo
//
//  Created by 张鼎辉 on 14-6-5.
//  Copyright (c) 2014年 ZhangDinghui. All rights reserved.
//

#import "ShareActionSheet.h"
#import "UIImage+Image.h"
#import "UIView+Screenshot.h"
#import "ShareTool.h"
#import "CShareObject.h"
#import "OauthModel.h"
#import "ShareViewController.h"

#define shareViewHeight 350
#define shareViewWidth [UIScreen mainScreen].bounds.size.width

#define kMarginWidth ([UIScreen mainScreen].bounds.size.width - kButtonWidth*3)/4

#define kButtonWidth 60
#define kButtonHeight 75
#define kTitleColor  [UIColor colorWithRed:(40/255.0) green:(40/255.0) blue:(40/255.0) alpha:0.9]


@interface ShareActionSheet (){
    UIImage *_currentViewImage;
    UIImageView *_shareView;
    
    ShareActionType _shareType;
    CShareObject *_shareObject;
}

@end

@implementation ShareActionSheet

- (ShareActionSheet *)initWithCurrentView:(UIView *)cView shareObject:(CShareObject *)shareObject delegate:(id)delegate{
    if(self = [super init]){
        _shareObject = shareObject;
        self.delegate = delegate;
        //获取屏幕截屏
        _currentViewImage = [cView convertViewToImage];
        //对_currentViewImage进行模糊处理
        _currentViewImage = [UIImage blurryImage:_currentViewImage WithBlurLevel:0.2];
        
        [self addControl];
    }
    return self;
}

#pragma mark 从新绘制view
- (void)loadView{
    UIImageView *bView = [[UIImageView alloc]initWithFrame:[UIScreen mainScreen].bounds];
    bView.image = _currentViewImage;
    bView.userInteractionEnabled = YES;
    UIImageView *cover = [[UIImageView alloc]initWithFrame:[UIScreen mainScreen].bounds];
    cover.backgroundColor = [UIColor blackColor];
    cover.alpha = 0.2;
    cover.userInteractionEnabled = YES;
    [cover addGestureRecognizer:[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(closeVC)]];
    [bView addSubview:cover];
    self.view = bView;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self openView];
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
}


#pragma mark 添加控件
- (void)addControl{
    
    //分享面板
    _shareView = [[UIImageView alloc]init];
    _shareView.backgroundColor = [UIColor colorWithRed:(232/255.0) green:(232/255.0) blue:(232/255.0) alpha:0.96];
    _shareView.userInteractionEnabled = YES;
    _shareView.alpha = 0.9;
    _shareView.frame = CGRectMake(0, [UIScreen mainScreen].bounds.size.height, shareViewWidth, shareViewHeight);
    [self.view addSubview:_shareView];
    
    //分享到
    UILabel *title = [[UILabel alloc]init];
    title.frame = CGRectMake(kMarginWidth, 10, 60, 20);
    title.font = [UIFont systemFontOfSize:14];
    title.textColor = kTitleColor;
    title.text = @"分享到：";
    [_shareView addSubview:title];
    
    //添加按钮
    [self addShareButtonWithTitle:@"微信好友" image:@"wechatFirend" index:0 tag:Share_WechatFirend];
    [self addShareButtonWithTitle:@"微信朋友圈" image:@"wechatCircle" index:1 tag:Share_WechatCircle];
    [self addShareButtonWithTitle:@"腾讯微博" image:@"tencentWB" index:2 tag:Share_TencentWB];
    
    [self addShareButtonWithTitle:@"手机QQ" image:@"tencentQQ" index:3 tag:Share_TencentQQ];
    
    [self addShareButtonWithTitle:@"QQ空间" image:@"tencentQZone" index:4 tag:Share_TencentQzone];
    
    [self addShareButtonWithTitle:@"新浪微博" image:@"sina.jpg" index:5 tag:Share_Sina];
    
    [self addShareButtonWithTitle:@"人人网" image:@"renren" index:6 tag:Share_RenRen];
    
    [self addShareButtonWithTitle:@"开心网" image:@"kaixin.jpg" index:7 tag:Share_Kaixin];
    
    //添加分割线
    UIButton *shareBut = (UIButton *)[self.view viewWithTag:Share_Kaixin];
    
    UILabel *line = [[UILabel alloc]init];
    line.frame = CGRectMake(0, CGRectGetMaxY(shareBut.frame)+20, [UIScreen mainScreen].bounds.size.width, 0.5);
    line.backgroundColor = [UIColor colorWithRed:(180/255.0) green:(180/255.0) blue:(180/255.0) alpha:0.96];
    [_shareView addSubview:line];
    
    //取消按钮
    UIButton *cancel = [UIButton buttonWithType:UIButtonTypeCustom];
    cancel.frame = CGRectMake([UIScreen mainScreen].bounds.size.width/2 - 70/2, CGRectGetMaxY(line.frame), 70, _shareView.frame.size.height - CGRectGetMaxY(line.frame));
    [cancel setTitle:@"取 消" forState:UIControlStateNormal];
    [cancel setTitleColor:[UIColor colorWithRed:(43/255.0) green:1 blue:(100/255.0) alpha:0.9] forState:UIControlStateNormal];
    [cancel setTitleShadowColor:[UIColor colorWithRed:(50/255.0) green:1 blue:(120/255.0) alpha:0.6] forState:UIControlStateNormal];
    cancel.titleLabel.font = [UIFont boldSystemFontOfSize:20];
    [cancel addTarget:self action:@selector(closeVC) forControlEvents:UIControlEventTouchUpInside];
    [_shareView addSubview:cancel];
}

#pragma mark 添加按钮
- (void)addShareButtonWithTitle:(NSString *)title image:(NSString *)image index:(int)index tag:(int)tag{
    UIButton *shareButton = [UIButton buttonWithType:UIButtonTypeCustom];
    //计算按钮位置
    //横排
    int cross = index%3;
    //纵排
    int ver = index/3;
    CGRect frame  = CGRectMake(kMarginWidth * (cross+1) + kButtonWidth * cross, 10 * (ver+1) + kButtonHeight * ver + 30, kButtonWidth, kButtonHeight);
    shareButton.frame = frame;
    shareButton.tag = tag;
    [shareButton addTarget:self action:@selector(shareAction:) forControlEvents:UIControlEventTouchUpInside];
    [_shareView addSubview:shareButton];
    
    
    
    //内部图片
    UIImageView *shareIcon = [[UIImageView alloc]init];
    shareIcon.frame = CGRectMake(0, 0, kButtonWidth, kButtonWidth);
    shareIcon.image = [UIImage imageNamed:image];
    shareIcon.layer.cornerRadius = 5;
    shareIcon.layer.masksToBounds = YES;
    [shareButton addSubview:shareIcon];
    
    //title
    UILabel *iconTitle = [[UILabel alloc]init];
    iconTitle.frame = CGRectMake(0, CGRectGetMaxY(shareIcon.frame)+3, kButtonWidth, 10);
    iconTitle.font = [UIFont systemFontOfSize:12];
    iconTitle.textColor = kTitleColor;
    iconTitle.textAlignment = NSTextAlignmentCenter;
    iconTitle.text = title;
    [shareButton addSubview:iconTitle];
}


#pragma mark openView
- (void)openView{
    [UIView animateWithDuration:0.4 animations:^{
        CGRect viewFrame = _shareView.frame;
        viewFrame.origin.y -= shareViewHeight;
        _shareView.frame = viewFrame;
    }];
}
#pragma mark closeView
- (void)closeViewIsCloseVC:(BOOL)isClose{
    [UIView animateWithDuration:0.4 animations:^{
        CGRect viewFrame = _shareView.frame;
        viewFrame.origin.y += shareViewHeight;
        _shareView.frame = viewFrame;
    } completion:^(BOOL finished) {
        if(isClose){
            [self dismissViewControllerAnimated:NO completion:nil];
        }
        
    }];
}



- (void)closeVC{
    [self closeViewIsCloseVC:YES];
}

- (void)shareAction:(UIButton *)sender{
    [self shareActionResult:sender.tag];
}


#pragma mark 按照分享类型分享
- (void)shareActionResult:(ShareActionType)shareType{
    _shareType = shareType;
    ShareTool *tool = [ShareTool shareWithObject:_shareObject];
    switch (shareType) {
        case Share_Kaixin:
        {
            /**
             犹豫授权问题赞实现不了
             */
            
        }
            break;
        case Share_RenRen:
        {
            RenRen *renren = [OauthModel shareOauthModel].renren;
            if(!renren){
                [self presentViewController:[[OauthControl alloc] initOauthWithType:kRenRenOauth delegate:self] animated:YES completion:nil];
            }else{
                ShareViewController *shareVC = [[ShareViewController alloc]init];
                shareVC.shareType = _shareType;
                shareVC.shareObject = _shareObject;
                [self closeViewIsCloseVC:NO];
                [self dismissViewControllerAnimated:NO completion:^{
                    [self.delegate openShareController:shareVC];
                }];
                
            }
        }
            break;
        case Share_Sina:
        {
            SinaOauth *sina = [OauthModel shareOauthModel].sina;
            if(!sina){
                [self presentViewController:[[OauthControl alloc] initOauthWithType:kSinaOauth delegate:self] animated:YES completion:nil];
            }else{
                
            }
        }
            break;
        case Share_TencentQQ:
        {
            TencentOAuth *qq = [OauthControl shareOahtuController].tenxunOauth;
            if(!qq){
                [self presentViewController:[[OauthControl alloc] initOauthWithType:kTencentQqOauth delegate:self] animated:YES completion:nil];
            }else{
                [self closeVC];
                [tool shareToTencentQQFirend];
            }
        }
            break;
        case Share_TencentQzone:
        {
            TencentOAuth *qq = [OauthControl shareOahtuController].tenxunOauth;
            if(!qq){
                [self presentViewController:[[OauthControl alloc] initOauthWithType:kTencentQqOauth delegate:self] animated:YES completion:nil];
            }else{
                
                [tool shareToTencentZone];
                
            }
            
        }
            break;
        case Share_TencentWB:
        {
            TenxunWB *wb = [OauthModel shareOauthModel].tencentWB;
            if(!wb){
                [self presentViewController:[[OauthControl alloc] initOauthWithType:kTencentWbOauth delegate:self] animated:YES completion:nil];
            }else{
                ShareViewController *shareVC = [[ShareViewController alloc]init];
                shareVC.shareType = _shareType;
                shareVC.shareObject = _shareObject;
                [self closeViewIsCloseVC:NO];
                [self dismissViewControllerAnimated:NO completion:^{
                    [self.delegate openShareController:shareVC];
                }];
           }
        }
            break;
        case Share_WechatCircle:
        {
            
            [tool shareToWechatFirendCircle];
        }
            break;
        case Share_WechatFirend:
        {
            
            [tool shareToWechatFirend];
        }
            break;
            
        default:
            break;
    }
}
- (void)resultWithOauthType:(OauthEnum)oauthType isOauth:(BOOL)isOk errorMsg:(NSString *)msg{
    if(isOk){
        [self shareActionResult:_shareType];
    }
}



@end
