//
//  RootViewController.h
//  ThirdPartyPlatformDemo
//
//  Created by 张鼎辉 on 14-6-4.
//  Copyright (c) 2014年 ZhangDinghui. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ShareActionSheet.h"

#import "OauthControl.h"
@interface RootViewController : UIViewController<ShareActionDelegate>

@end
