//
//  RootViewController.m
//  ThirdPartyPlatformDemo
//
//  Created by 张鼎辉 on 14-6-4.
//  Copyright (c) 2014年 ZhangDinghui. All rights reserved.
//

#import "RootViewController.h"
#import "ShareTool.h"
#import "ShareViewController.h"
@interface RootViewController (){
    CShareObject *shareObject;
    
    NSString *title;
    NSString *desc;
    NSString *imageUrl;
    NSString *videoUrl;
    NSData   *imageData;
    ShareActionType _shareType;
}

@end

@implementation RootViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        
            
        
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    title = @"其实我只是想测试而已 何必那么认真";
    desc = @"其实我只是想测试而已 何必那么认真 这个是详情";
    imageUrl = @"http://d.hiphotos.baidu.com/image/pic/item/7aec54e736d12f2eea08b67e4dc2d5628535689a.jpg";
    videoUrl = @"http://v.youku.com/v_show/id_XNzIxMTQ5ODc2.html?f=22318976&ev=3&from=y1.3-idx-grid-1519-9909.86808-86807.3-1";
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)shareText:(id)sender {
    shareObject = [CShareTextObject shareTextTitle:title  description:desc];
    [self openShare];
    
}


- (IBAction)shareImage:(id)sender {
    
    //获取图片
    __weak ASIHTTPRequest *data = [ASIHTTPRequest requestWithURL:[NSURL URLWithString:imageUrl]];
    [data startAsynchronous];
    [data setCompletionBlock:^{
        imageData = [data responseData];
        int length = imageData.length;
        int MB = length>>20;
        if(MB > 4){
            UIImage *image = [UIImage imageWithData:imageData];
            image = [UIImage compressWithImageName:image];
            imageData = UIImageJPEGRepresentation(image, 0.5);
        }
        
        shareObject = [CShareImageObject shareImagesTitle:title description:desc imageData:imageData];
        [self openShare];
    }];

    
}


- (IBAction)shareVideo:(id)sender {
    shareObject = [CShareVideoObject shareVideoTitle:title description:desc videoUrl:videoUrl iconUrl:imageUrl iconData:nil];
    [self openShare];
}


- (void)openShare{
    
    [self presentViewController:[[ShareActionSheet alloc] initWithCurrentView:self.view shareObject:shareObject delegate:self]animated:NO completion:nil];
}

- (void)shareActionResult:(BOOL)isOk{
    if (isOk) {
        [[[UIAlertView alloc]initWithTitle:@"提示" message:@"分享成功" delegate:nil cancelButtonTitle:@"知道了" otherButtonTitles:nil, nil] show];
    }
}

- (void)openShareController:(ShareViewController *)shareVC{
    shareVC.shareResult = ^(BOOL isOk){
        if(isOk){
            [[[UIAlertView alloc]initWithTitle:@"提示" message:@"分享成功" delegate:nil cancelButtonTitle:@"知道了" otherButtonTitles:nil, nil]show];
        }else{
            [[[UIAlertView alloc]initWithTitle:@"提示" message:@"分享失败" delegate:nil cancelButtonTitle:@"知道了" otherButtonTitles:nil, nil]show];
        }
    };
    [self presentViewController:shareVC animated:YES completion:nil];
}

@end
