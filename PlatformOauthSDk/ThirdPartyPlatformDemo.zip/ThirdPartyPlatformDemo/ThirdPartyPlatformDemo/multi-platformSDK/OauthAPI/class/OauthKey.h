



/**
 * 第三方授权所需要的东西
 */

//新浪
#define kSina_AppKey    @"3688243597"
#define kSina_AppSecret @"af2238687f328bb5d37b2e89a8386548"
#define kSina_RedirectURI  @"https://api.weibo.com/oauth2/default.html"

//腾讯微博
#define kTenxunWB_AppKey @"801509380"
#define kTenxunWB_Secret @"ee738d7f3bc3f230f0e46643317d2600"
#define kTenxunWB_RedirectUri @"http://www.doodoll.com"


//人人网
#define kRenRen_AppKey  @"dd2a3df7a3784475afe6259bcddd8cec"
#define kRenRen_APPId   @"268428"
#define kRenRen_AppSecrect @"aa4667a67a56419a8e7d3e0baf5b6d96"
#define kRenRen_RedirectUri @"http://graph.renren.com/oauth/login_success.html"

//开心网
#define kKaiXin_AppKey @"689536791996a03a2c535778bfee6da3"
#define kKaiXin_Secret @"3c71260ff769a37e2660af908f4c31d3"
#define kKaiXin_AppID  @"100060446"
#define kKaiXin_RedirectUri @"http://www.doodoll.com"


//QQ
#define kTenxunQQ_AppId  @"1101473555"
#define kTenxunQQ_AppKey @"4UOlG6tLg4imkVSy"

//微信
#define kWeixin_AppId @"wx1fae8ea3bb189a98"
#define kWeixin_AppSecret @"02a72692462c565aac171d241c509248"