//
//  DeviceIp.h
//  ThirdPartyPlatformDemo
//
//  Created by 张鼎辉 on 14-5-30.
//  Copyright (c) 2014年 ZhangDinghui. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DeviceIp : NSObject

/**
 获取当前ip
 */
+ (NSString *)getDeviceIp;
@end
