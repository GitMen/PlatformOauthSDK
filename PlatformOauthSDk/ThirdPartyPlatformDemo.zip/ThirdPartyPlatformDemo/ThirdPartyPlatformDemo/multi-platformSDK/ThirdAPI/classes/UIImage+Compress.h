//
//  UIImage+Compress.h
//  ThirdPartyPlatformDemo
//
//  Created by 张鼎辉 on 14-5-30.
//  Copyright (c) 2014年 ZhangDinghui. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (Compress)


///剪切图片
+ (UIImage *)compressWithImageName:(UIImage *)imageIcon;

@end
