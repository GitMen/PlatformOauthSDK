//
//  MainViewController.h
//  ThirdPartyPlatformDemo
//
//  Created by 张鼎辉 on 14-5-27.
//  Copyright (c) 2014年 ZhangDinghui. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MainViewController : UIViewController<BaseOauthDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate>





@end
