//
//  UIView+Screenshot.h
//  ACTTAO_Doodoll
//
//  Created by 李蝉 on 14-4-26.
//  Copyright (c) 2014年 李蝉. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (Screenshot)

#pragma mark 获取当前屏幕的截图
-(UIImage *)convertViewToImage;

@end
