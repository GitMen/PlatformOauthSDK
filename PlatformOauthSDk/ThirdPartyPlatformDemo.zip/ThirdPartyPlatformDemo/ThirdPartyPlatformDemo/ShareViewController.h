//
//  ShareViewController.h
//  ThirdPartyPlatformDemo
//
//  Created by 张鼎辉 on 14-6-5.
//  Copyright (c) 2014年 ZhangDinghui. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ShareActionSheet.h"
@interface ShareViewController : UIViewController<UITextViewDelegate>

/**
 分享结果
 */

@property (nonatomic,assign)ShareActionType shareType;

@property (nonatomic,strong)CShareObject *shareObject;


@property (nonatomic,copy)void (^shareResult)(BOOL isOk);

@end
