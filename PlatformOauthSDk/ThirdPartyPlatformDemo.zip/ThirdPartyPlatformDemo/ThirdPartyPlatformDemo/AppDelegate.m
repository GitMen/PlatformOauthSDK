//
//  AppDelegate.m
//  ThirdPartyPlatformDemo
//
//  Created by 张鼎辉 on 14-5-27.
//  Copyright (c) 2014年 ZhangDinghui. All rights reserved.
//

#import "AppDelegate.h"
#import "RootViewController.h"
#import "WechatWriteMessageApi.h"
@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    // Override point for customization after application launch.
    self.window.backgroundColor = [UIColor whiteColor];
    
    self.window.rootViewController = [[RootViewController alloc]initWithNibName:@"RootViewController" bundle:nil];
    
    
    [self.window makeKeyAndVisible];
    return YES;
}

- (BOOL)application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation
{
    //处理网络请求的数据传输
    return [[OauthControl shareOahtuController]handleOpenUrl:url];
}

- (BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url{
    //处理网络请求的数据传输
    return [[OauthControl shareOahtuController]handleOpenUrl:url];
}




@end
