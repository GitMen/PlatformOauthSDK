//
//  ShareViewController.m
//  ThirdPartyPlatformDemo
//
//  Created by 张鼎辉 on 14-6-5.
//  Copyright (c) 2014年 ZhangDinghui. All rights reserved.
//

#import "ShareViewController.h"
#import "UIImageView+WebCache.h"
#import "ShareTool.h"
#import "MBProgressHUD+Show.h"
#define kTopViewHeight 62
#define kButtonHeight 30
#define kButtonWidth 40
#define kButtonColor [UIColor colorWithRed:(30/255.0) green:(79/255.0) blue:(138/255.0) alpha:1]
@interface ShareViewController (){
    UILabel *_title;
    UIImageView *_topView;
    UIButton *_cancel;
    UIButton *_send;
    
    UITextView *_textView;

    //sharePanel
    UIImageView *_sharePanel;
    UIImageView *_shareIcon;
    UILabel *_shareTitle;
    UILabel *_shareDesc;
}

@end

@implementation ShareViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.view.backgroundColor = [UIColor whiteColor];
        [self addControl];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
}

- (void)addControl{
    CGRect frame = [UIScreen mainScreen].bounds;
    //topView
    _topView= [[UIImageView alloc]init];
    _topView.frame = CGRectMake(0, 0, frame.size.width, kTopViewHeight);
    _topView.backgroundColor = [UIColor colorWithRed:(232/255.0) green:(232/255.0) blue:(232/255.0) alpha:0.96];
    _topView.userInteractionEnabled = YES;
    [self.view addSubview:_topView];
    
    //cancel
    _cancel = [UIButton buttonWithType:UIButtonTypeCustom];
    _cancel.frame = CGRectMake(10, kTopViewHeight/2-kButtonHeight/2 + 20, kButtonWidth, kButtonHeight);
    [_cancel setTitle:@"取消" forState:UIControlStateNormal];
    [_cancel setTitleColor:kButtonColor forState:UIControlStateNormal];
    [_cancel addTarget:self action:@selector(cancelAction) forControlEvents:UIControlEventTouchUpInside];
    _cancel.titleLabel.font = [UIFont systemFontOfSize:14];
    [_topView addSubview:_cancel];
    
    //send
    _send = [UIButton buttonWithType:UIButtonTypeCustom];
    _send.frame = CGRectMake(frame.size.width-10-kButtonWidth, kTopViewHeight/2-kButtonHeight/2+ 20, kButtonWidth, kButtonHeight);
    [_send setTitle:@"分享" forState:UIControlStateNormal];
    [_send setTitleColor:kButtonColor forState:UIControlStateNormal];
    [_send addTarget:self action:@selector(sendAction) forControlEvents:UIControlEventTouchUpInside];
    _send.titleLabel.font = [UIFont systemFontOfSize:14];
    [_topView addSubview:_send];
    
    
    //title
    _title = [[UILabel alloc]init];
    _title.frame = CGRectMake(kButtonWidth+10,  kTopViewHeight/2-kButtonHeight/2+ 20, frame.size.width - kButtonWidth*2 -20, kButtonHeight);
    _title.textAlignment = NSTextAlignmentCenter;
    _title.textColor = [UIColor colorWithRed:(235/255.0) green:(107/255.0) blue:(0/255.0) alpha:1];
    _title.font = [UIFont systemFontOfSize:18];
    [_topView addSubview:_title];
    
    UILabel *line = [[UILabel alloc]init];
    line.frame = CGRectMake(0, _topView.frame.size.height-0.5, 320, 0.5);
    line.backgroundColor = [UIColor grayColor];
    [_topView addSubview:line];
    
    
    //textView
    _textView = [[UITextView alloc]init];
    _textView.frame = CGRectMake(10, CGRectGetMaxY(_topView.frame)+10, frame.size.width-20, 70);
    _textView.returnKeyType = UIReturnKeyDone;
    _textView.text = @"说点什么吧...";
    _textView.layer.cornerRadius = 5;
    _textView.layer.masksToBounds = YES;
    _textView.delegate = self;
    _textView.textColor = [UIColor grayColor];
    [self.view addSubview:_textView];
    
    
    [self createSharePanel];

}

- (void)createSharePanel{
    
    CGRect frame = [UIScreen mainScreen].bounds;

    _sharePanel = [[UIImageView alloc]init];
    _sharePanel.frame = CGRectMake(5, CGRectGetMaxY(_textView.frame)+40, frame.size.width-10, 70);
    _sharePanel.layer.borderColor = [UIColor colorWithRed:(232/255.0) green:(232/255.0) blue:(232/255.0) alpha:0.96].CGColor;
    _sharePanel.layer.borderWidth = 0.3;
    [self.view addSubview:_sharePanel];
    
    _shareIcon = [[UIImageView alloc]init];
    _shareIcon.frame = CGRectMake(0, 0 , 70 , 70);
    [_sharePanel addSubview:_shareIcon];
    
    _shareTitle = [[UILabel alloc]init];
    _shareTitle.frame = CGRectMake(CGRectGetMaxX(_shareIcon.frame)+15, 15, _sharePanel.frame.size.width - CGRectGetMaxX(_shareIcon.frame) - 10, 20);
    _shareTitle.textColor = [UIColor colorWithRed:(190/255.0) green:(190/255.0) blue:(190/255.0) alpha:0.96];
    _shareTitle.font = [UIFont boldSystemFontOfSize:12];
    [_sharePanel addSubview:_shareTitle];
    
    _shareDesc = [[UILabel alloc]init];
    _shareDesc.frame = CGRectMake(CGRectGetMaxX(_shareIcon.frame)+15, CGRectGetMaxY(_shareTitle.frame)+5, _sharePanel.frame.size.width - CGRectGetMaxX(_shareIcon.frame) - 10, _sharePanel.frame.size.height - CGRectGetMaxY(_shareTitle.frame) - 20);
    _shareDesc.textColor = [UIColor colorWithRed:(190/255.0) green:(190/255.0) blue:(190/255.0) alpha:0.96];
    _shareDesc.numberOfLines = 0;
    _shareDesc.font = [UIFont systemFontOfSize:12];
    [_sharePanel addSubview:_shareDesc];
    
}


#pragma mark 开始分享
- (void)sendAction{
    
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    hud.layer.cornerRadius = 5;
    hud.labelText = [NSString stringWithFormat:@"%@...",_title.text];
    
    
    
    _shareObject.description = [NSString stringWithFormat:@"%@ >> %@",_shareObject.title,_shareObject.description];
    _shareObject.title = _textView.text;
    ShareTool * tool= [ShareTool shareWithObject:_shareObject];
    switch (self.shareType) {
        case Share_Kaixin:{
            [tool shareToKaixinWithSuccess:^{
                
                [MBProgressHUD hideHUDForView:self.view animated:YES];
                [self dismissViewControllerAnimated:YES completion:nil];
                self.shareResult(YES);
                
            } fail:^{
                [MBProgressHUD hideHUDForView:self.view animated:YES];
                [self dismissViewControllerAnimated:YES completion:nil];
                self.shareResult(NO);
            }];
        }
            break;
        case Share_RenRen:{
            [tool shareToRenrenWithSuccess:^{
                [MBProgressHUD hideHUDForView:self.view animated:YES];
                [self dismissViewControllerAnimated:YES completion:nil];
                self.shareResult(YES);
            } fail:^{
                [MBProgressHUD hideHUDForView:self.view animated:YES];
                [self dismissViewControllerAnimated:YES completion:nil];
                self.shareResult(NO);
            }];
        }
            break;
        case Share_Sina:{
            [tool shareToSianWithSuccess:^{
                [MBProgressHUD hideHUDForView:self.view animated:YES];
                [self dismissViewControllerAnimated:YES completion:nil];
                self.shareResult(YES);
            } fail:^{
                [MBProgressHUD hideHUDForView:self.view animated:YES];
                [self dismissViewControllerAnimated:YES completion:nil];
                self.shareResult(NO);
            }];
        }
            break;
        case Share_TencentWB:{
            [tool shareToTencentWBWithSuccess:^{
                [MBProgressHUD hideHUDForView:self.view animated:YES];
                [self dismissViewControllerAnimated:YES completion:nil];
                self.shareResult(YES);
            } fail:^{
                [MBProgressHUD hideHUDForView:self.view animated:YES];
                [self dismissViewControllerAnimated:YES completion:nil];
                self.shareResult(NO);
            }];
        }
            break;
        default:
            break;
    }
}

- (void)cancelAction{
    [self dismissViewControllerAnimated:YES completion:nil];
}
#pragma mark 根据分享模型判断类型
- (void)setShareObject:(CShareObject *)shareObject{
    _shareObject = shareObject;
    
    _shareTitle.text = shareObject.title;
    _shareDesc.text = shareObject.description;
    if([shareObject isKindOfClass:[CShareTextObject class]]){
        _shareIcon.hidden = YES;
        _shareTitle.frame = CGRectMake(10, 10, _sharePanel.frame.size.width - CGRectGetMaxX(_shareIcon.frame) - 10, 20);
        _shareDesc.frame = CGRectMake(10, CGRectGetMaxY(_shareTitle.frame)+5, _sharePanel.frame.size.width - CGRectGetMaxX(_shareIcon.frame) - 10, _sharePanel.frame.size.height - CGRectGetMaxY(_shareTitle.frame) - 20);
        
       
    }
    
    if([shareObject isKindOfClass:[CShareImageObject class]]){
        if(shareObject.imageData.length != 0){
            _shareIcon.image = [UIImage imageWithData:shareObject.imageData];
        }else{
            [_shareIcon setImageWithURL:[NSURL URLWithString:shareObject.imageUrl] placeholderImage:nil];
        }
    }
    
    if([shareObject isKindOfClass:[CShareVideoObject class]]){
        if(shareObject.iconData.length != 0){
            _shareIcon.image = [UIImage imageWithData:shareObject.iconData];
        }else{
            [_shareIcon setImageWithURL:[NSURL URLWithString:shareObject.iconUrl] placeholderImage:nil];
        }
    }
    
    if([shareObject isKindOfClass:[CSharePageObject class]]){
        if(shareObject.iconData.length != 0){
            _shareIcon.image = [UIImage imageWithData:shareObject.iconData];
        }else{
            [_shareIcon setImageWithURL:[NSURL URLWithString:shareObject.iconUrl] placeholderImage:nil];
        }
    }
 
    
}

- (void)setShareType:(ShareActionType )shareType{
    _shareType = shareType;
    
    
   
    switch (shareType) {
        case Share_Kaixin:{
            _title.text = @"分享到开心网";
        }
            break;
        case Share_RenRen:{
            _title.text = @"分享到人人网";
        }
            break;
        case Share_Sina:{
            _title.text = @"分享到新浪微博";
        }
            break;
        case Share_TencentWB:{
            _title.text = @"分享到腾讯微博";
        }
            break;
        default:
            break;
    }
    
    
}

#pragma mark textViewDelegate
- (void)textViewDidBeginEditing:(UITextView *)textView{
    _textView.text = @"";
    _textView.textColor = [UIColor blueColor];
}

- (void)textViewDidEndEditing:(UITextView *)textView{
    if([_textView.text isEqualToString:@""]){
        _textView.text = @"说点什么吧";
        _textView.textColor = [UIColor grayColor];
    }
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    [self.view endEditing:YES];
}

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text{
    
    if([text isEqualToString:@"\n"]){
        [_textView resignFirstResponder];
        return NO;
    }
    
    
    return YES;
}

@end
