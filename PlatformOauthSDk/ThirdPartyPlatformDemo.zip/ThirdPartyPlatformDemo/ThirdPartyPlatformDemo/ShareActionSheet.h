//
//  ShareActionSheet.h
//  ThirdPartyPlatformDemo
//
//  Created by 张鼎辉 on 14-6-5.
//  Copyright (c) 2014年 ZhangDinghui. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "OauthControl.h"
#import "CShareObject.h"

@class ShareViewController;
typedef enum{
    Share_WechatFirend = 87<<2,
    Share_WechatCircle,
    Share_TencentWB,
    Share_TencentQQ,
    Share_TencentQzone,
    Share_RenRen,
    Share_Kaixin,
    Share_Sina
}ShareActionType;

@protocol ShareActionDelegate <NSObject>

- (void)shareActionResult:(BOOL)isOk;

/**
 需要以模态试图的方式推入到此控制器
 */
- (void)openShareController:(ShareViewController *)shareVC;


@end


@interface ShareActionSheet : UIViewController<BaseOauthDelegate>

/**
 初始化函数，需要传入当前屏幕view
 分享数据模型，按照不同类型传入
 */
- (ShareActionSheet *)initWithCurrentView:(UIView *)cView shareObject:(CShareObject *)shareObject delegate:(id)delegate ;

/**
 分享选择结果代理
 */
@property (nonatomic,strong)id<ShareActionDelegate> delegate;

@end

