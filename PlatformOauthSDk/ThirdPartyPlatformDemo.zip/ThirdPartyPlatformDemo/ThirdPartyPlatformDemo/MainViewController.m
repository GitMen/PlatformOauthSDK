//
//  MainViewController.m
//  ThirdPartyPlatformDemo
//
//  Created by 张鼎辉 on 14-5-27.
//  Copyright (c) 2014年 ZhangDinghui. All rights reserved.
//

#import "MainViewController.h"
#import "OauthModel.h"
#import "ThirdApi.h"
#import <MobileCoreServices/MobileCoreServices.h>
#import <AssetsLibrary/AssetsLibrary.h> //访问的图库

@interface MainViewController (){
    //图片抓取器
    UIImagePickerController *_imagePickerController;
    UIImage *_image;
    WechatWriteMessageApi *api;

}

@end

@implementation MainViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    UIButton *but = [UIButton buttonWithType:UIButtonTypeCustom];
    but.frame = CGRectMake(50, 150, 100, 50);
    but.backgroundColor = [UIColor brownColor];
    [but setTitle:@"text" forState:UIControlStateNormal];
    [but addTarget:self action:@selector(textApi) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:but];
}

- (void)viewWillAppear:(BOOL)animated{
    [WechatWriteMessageApi registerWechatWithAppId:kWeixin_AppId withDescription:@"肚兜云"];
   


    
}


#pragma mark 测试api
- (void)textApi{


    Kaixin *renren = [OauthModel shareOauthModel].kaixin;
    if(!renren){
        [self presentViewController:[[OauthControl alloc] initOauthWithType:kKaixinOauth delegate:self] animated:YES completion:nil];
    }else{

        [KaixinWriteMessageApi sendImageStatusWithAccessToken:renren.accessToken content:@"123123" imageFilePath:@"" imageUrl:@"" successed:^(NSDictionary *newStatus) {
            
        } fail:^{
            
        }];
//        //检查是否有图库
//        if(![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypePhotoLibrary]){
//            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"警告" message:@"对不起,您的设备没有图片库" delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
//            [alert show];
//            return;
//        }
//        //检查图片选取器是否存在,不存在则创建
//        if(!_imagePickerController){
//            _imagePickerController = [[UIImagePickerController alloc]init];
//            _imagePickerController.delegate = self;
//        }
//        
//        //设定照相机可以获取哪些类型媒体
//        _imagePickerController.mediaTypes = @[(NSString *)kUTTypeMovie , (NSString *)kUTTypeImage];
//        
//        //设定图片的来源来自图片库
//        _imagePickerController.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
//        
//        //打开图片选取器视图
//        [self presentViewController:_imagePickerController animated:YES completion:nil];
    }
    
    
}



- (void)resultWithOauthType:(OauthEnum)oauthType isOauth:(BOOL)isOk errorMsg:(NSString *)msg{
    if(isOk){
        
    }
}


- (void):(NSString *)mediaType{
    //检查是否有相机（图片选取器的isSourceTypeAvailable类方法）
    if(![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]){
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"警告" message:@"对不起,您的设备没有照相功能" delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
        [alert show];
        return;
    }
    
    
    
    //检查图片选取器是否存在，不存在创建并指定委托
    if(!_imagePickerController){
        _imagePickerController = [[UIImagePickerController alloc]init];
        _imagePickerController.delegate = self;
    }
    //设定照相机可以获取那些类型的媒体（图片选取器的mediaTypes属性kUTTypeMovie或者kUTTypeImage）
    _imagePickerController.mediaTypes = @[mediaType];
    
    //设定图片的来源为摄像头（图片选取器的sourceType属性UIImagePickerControllerSourceTypeCamera）
    _imagePickerController.sourceType = UIImagePickerControllerSourceTypeCamera;
    
    //设定图片选取器的摄像头捕获模式（图片选取器的cameraCaptureMode属性UIImagePickerControllerCameraCaptureModePhoto或者UIImagePickerControllerCameraCaptureModeVideo）
    _imagePickerController.cameraCaptureMode = UIImagePickerControllerCameraCaptureModePhoto
    |UIImagePickerControllerCameraCaptureModeVideo;
    
    //设置图片品质
    _imagePickerController.videoQuality = UIImagePickerControllerQualityTypeHigh | UIImagePickerControllerQualityTypeIFrame1280x720;
    
    //打开图片选取器视图控制器（模态视图方式）
    [self presentViewController:_imagePickerController animated:YES completion:nil];
    
}



- (void)operationImage:(NSDictionary *)info imagePickerController:(UIImagePickerController *)picker{
    //获取图片
    UIImage *image = info[UIImagePickerControllerOriginalImage];
    
    _image = image;
    
    
    //如果图片选择器的类型类摄像头
    if(picker.sourceType == UIImagePickerControllerSourceTypeCamera){
        //将照片存入系统相册
        UIImageWriteToSavedPhotosAlbum(image, nil, nil, nil);
    }
}

#pragma mark _imagePickerController的委托
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info{
    //从info字典中获取媒体类型
    NSString *mediaType = info[UIImagePickerControllerMediaType];
    //判断媒体类型是否为图片
    if([mediaType isEqualToString:(NSString *)kUTTypeImage]){
        //图片操作
        [self operationImage:info imagePickerController:picker];
    }
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker{
    //关闭图片选取器控制器
    [_imagePickerController dismissViewControllerAnimated:YES completion:nil];
    
    _image = [UIImage compressWithImageName:_image];
    NSData *data = UIImageJPEGRepresentation(_image, 0.1);
    NSString *path =  [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)[0] stringByAppendingPathComponent:@"file.jpg"];
    [data writeToFile:path atomically:YES];
    
}


@end
