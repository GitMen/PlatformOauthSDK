//
//  UIImage+Image.h
//  ACTTAO_Doodoll
//
//  Created by 李蝉 on 14-4-29.
//  Copyright (c) 2014年 李蝉. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (Image)

//更改尺寸
- (UIImage*)newTransformWidth:(CGFloat)width height:(CGFloat)height rotate:(BOOL)rotate;

//更改尺寸
-(UIImage*)getSubImage:(CGRect)rect;

//模糊图片
+ (UIImage *)blurryImage:(UIImage *)image WithBlurLevel:(CGFloat)blur;

///压缩图片
+ (UIImage *)compressWithImageName:(UIImage *)imageIcon;
@end
