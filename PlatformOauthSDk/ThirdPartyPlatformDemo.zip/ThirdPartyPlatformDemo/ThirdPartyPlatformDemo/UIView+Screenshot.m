//
//  UIView+Screenshot.m
//  ACTTAO_Doodoll
//
//  Created by 李蝉 on 14-4-26.
//  Copyright (c) 2014年 李蝉. All rights reserved.
//

#import "UIView+Screenshot.h"

@implementation UIView (Screenshot)


//屏幕截图转化到图片
-(UIImage *)convertViewToImage
{
    UIGraphicsBeginImageContext(self.bounds.size);
    [self drawViewHierarchyInRect:self.bounds afterScreenUpdates:YES];
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return image;
}

@end
