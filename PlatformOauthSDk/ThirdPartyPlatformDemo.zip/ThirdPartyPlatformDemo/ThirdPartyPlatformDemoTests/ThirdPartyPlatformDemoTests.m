//
//  ThirdPartyPlatformDemoTests.m
//  ThirdPartyPlatformDemoTests
//
//  Created by 张鼎辉 on 14-5-27.
//  Copyright (c) 2014年 ZhangDinghui. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface ThirdPartyPlatformDemoTests : XCTestCase

@end

@implementation ThirdPartyPlatformDemoTests

- (void)setUp
{
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown
{
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
